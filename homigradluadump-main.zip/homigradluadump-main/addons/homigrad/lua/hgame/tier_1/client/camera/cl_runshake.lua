-- "addons\\homigrad\\lua\\hgame\\tier_1\\client\\camera\\cl_runshake.lua"
-- Retrieved by https://github.com/lewisclark/glua-steal
//