-- "addons\\homigrad\\lua\\hgame\\tier_1\\inv\\sh_tier_0.lua"
-- Retrieved by https://github.com/lewisclark/glua-steal
Inv = Inv or {}
Inv.objects = Inv.objects or {}
