-- "addons\\homigrad\\lua\\hgamemode\\src\\client\\scoreboard\\pages\\standply_cl.lua"
-- Retrieved by https://github.com/lewisclark/glua-steal
//