-- "addons\\homigrad\\lua\\hgamemode\\src\\roundsystem\\playerclass\\ineedaboulets_sh.lua"
-- Retrieved by https://github.com/lewisclark/glua-steal
local CLASS = player.RegClass("ineedabullets")