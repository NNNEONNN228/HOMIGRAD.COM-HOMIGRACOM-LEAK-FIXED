-- "addons\\homigrad\\lua\\hgamemode\\src\\roundsystem\\levels\\tier_1_jailbreak\\maps_sh.lua"
-- Retrieved by https://github.com/lewisclark/glua-steal
hook.Add("PostCleanupMap","gm_fork",function()

end)