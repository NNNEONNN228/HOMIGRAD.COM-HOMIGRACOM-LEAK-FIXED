-- "gamemodes\\base\\entities\\entities\\base_entity\\cl_init.lua"
-- Retrieved by https://github.com/lewisclark/glua-steal

include( "shared.lua" )

--[[---------------------------------------------------------
	Name: Initialize
	Desc: First function called. Use to set up your entity
-----------------------------------------------------------]]
function ENT:Initialize()
end


--[[---------------------------------------------------------
	Name: Think
	Desc: Client Think - called every frame
-----------------------------------------------------------]]
function ENT:Think()
end

--[[---------------------------------------------------------
	Name: OnRestore
	Desc: Called immediately after a "load"
-----------------------------------------------------------]]
function ENT:OnRestore()
end
