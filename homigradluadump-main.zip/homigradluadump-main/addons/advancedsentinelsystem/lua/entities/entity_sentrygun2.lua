-- "addons\\advancedsentinelsystem\\lua\\entities\\entity_sentrygun2.lua"
-- Retrieved by https://github.com/lewisclark/glua-steal
AddCSLuaFile()

ENT.Base = "entity_sentrygun_reworked"
ENT.PrintName = "Sentinel_v2 ZOMBIE"
ENT.Category = "Frasiu's R&D"
ENT.Spawnable = true
ENT.AdminOnly = false
ENT.AutomaticFrameAdvance = true
ENT.m_iClass = CLASS_ZOMBIE
