if weaponClass == "act3_g17" then
                org = hand.Pos + hand.Ang:Up() * 2.5 - hand.Ang:Forward() * 8.3 + hand.Ang:Right() * -0.1
                ang = hand.Ang + Angle(-11,0,0)
            end
            if weaponClass == "act3_g21" then
                org = hand.Pos + hand.Ang:Up() * 2.5 - hand.Ang:Forward() * 8.3 + hand.Ang:Right() * -0.1
                ang = hand.Ang + Angle(-11,0,0)
            end
            if weaponClass == "act3_ak12" then
                org = hand.Pos + hand.Ang:Up() * 6.1 - hand.Ang:Forward() * 2.3 + hand.Ang:Right() * 0.8
                ang = hand.Ang + Angle(-5,-1,0)
            end
            if weaponClass == "act3_ak_mznak74" then
                org = hand.Pos + hand.Ang:Up() * 6.2 - hand.Ang:Forward() * 1.3 + hand.Ang:Right() * 0.8
                ang = hand.Ang + Angle(-5,-1,0)
            end
            if weaponClass == "act3_akmn" then
                org = hand.Pos + hand.Ang:Up() * 6.2 - hand.Ang:Forward() * 1.3 + hand.Ang:Right() * 0.8
                ang = hand.Ang + Angle(-5,-1,0)
            end
            if weaponClass == "act3_ak_mznaks74u" then
                org = hand.Pos + hand.Ang:Up() * 6.3 - hand.Ang:Forward() * 1.3 + hand.Ang:Right() * 0.8
                ang = hand.Ang + Angle(-5,-1,0)
            end
            if weaponClass == "act3_ak12_2012" then
                org = hand.Pos + hand.Ang:Up() * 6.1 - hand.Ang:Forward() * 2.3 + hand.Ang:Right() * 0.8
                ang = hand.Ang + Angle(-5,-1,0)
            end
            if weaponClass == "act3_mznar556" then
                org = hand.Pos + hand.Ang:Up() * 7 - hand.Ang:Forward() * 3 + hand.Ang:Right() * 1.1
                ang = hand.Ang + Angle(-5,-1,0)
            end
            if weaponClass == "act3_ar_mpx" then
                org = hand.Pos + hand.Ang:Up() * 6 - hand.Ang:Forward() * 3 + hand.Ang:Right() * 1.1
                ang = hand.Ang + Angle(-11,-1,0)
            end
            if weaponClass == "act3_mzngrach" then
                org = hand.Pos + hand.Ang:Up() * 3.8 - hand.Ang:Forward() * 6 + hand.Ang:Right() * 0.22
                ang = hand.Ang + Angle(-11,0,0)
            end
            if weaponClass == "act3_model29" then
                org = hand.Pos + hand.Ang:Up() * 4.3 - hand.Ang:Forward() * 6 + hand.Ang:Right() * 0.28
                ang = hand.Ang + Angle(-11,0,0)
            end
            if weaponClass == "act3_m9" then
                org = hand.Pos + hand.Ang:Up() * 4.4 - hand.Ang:Forward() * 6 + hand.Ang:Right() * 0.24
                ang = hand.Ang + Angle(-5,0,0)
            end
            if weaponClass == "act3_ou" then
                org = hand.Pos + hand.Ang:Up() * 3 - hand.Ang:Forward() * 3 + hand.Ang:Right() * 0.8
                ang = hand.Ang + Angle(-15,0,0)
            end
            if weaponClass == "act3_m122" then
                org = hand.Pos + hand.Ang:Up() * 3.4 - hand.Ang:Forward() * 3 + hand.Ang:Right() * 1.2
                ang = hand.Ang + Angle(-11,-1,0)
            end
            if weaponClass == "act3_lior" then
                org = hand.Pos + hand.Ang:Up() * 5.6 - hand.Ang:Forward() * 3 + hand.Ang:Right() * 1.45
                ang = hand.Ang + Angle(-11,-1,0)
            end
            if weaponClass == "act3_p1" then
                org = hand.Pos + hand.Ang:Up() * 2.4 - hand.Ang:Forward() * 6 + hand.Ang:Right() * 0.55
                ang = hand.Ang + Angle(-15,0,0)
            end
            if weaponClass == "act3_blackhawk" then
                org = hand.Pos + hand.Ang:Up() * 4.2 - hand.Ang:Forward() * 6 + hand.Ang:Right() * 0.22
                ang = hand.Ang + Angle(-10,0,0)
            end
            if weaponClass == "act3_p220" then
                org = hand.Pos + hand.Ang:Up() * 3.8 - hand.Ang:Forward() * 6 + hand.Ang:Right() * 0.15
                ang = hand.Ang + Angle(-5,0,0)
            end
            if weaponClass == "act3_usp" then
                org = hand.Pos + hand.Ang:Up() * 4 - hand.Ang:Forward() * 6 + hand.Ang:Right() * 0.23
                ang = hand.Ang + Angle(-5,0,0)
            end
            if weaponClass == "act3_m1911" then
                org = hand.Pos + hand.Ang:Up() * 3.35 - hand.Ang:Forward() * 6 + hand.Ang:Right() * 0.28
                ang = hand.Ang + Angle(-5,0,0)
            end
            if weaponClass == "act3_fiveseven" then
                org = hand.Pos + hand.Ang:Up() * 3.9 - hand.Ang:Forward() * 6 + hand.Ang:Right() * 0.12
                ang = hand.Ang + Angle(-5,0,0)
            end
            if weaponClass == "act3_deagle" then
                org = hand.Pos + hand.Ang:Up() * 4.3 - hand.Ang:Forward() * 6 + hand.Ang:Right() * 0.28
                ang = hand.Ang + Angle(-5,0,0)
            end
            if weaponClass == "act3_mp5" then
                org = hand.Pos + hand.Ang:Up() * 7.4 - hand.Ang:Forward() * -2 + hand.Ang:Right() * 0.96
                ang = hand.Ang + Angle(-5,-3,0)
            end
            if weaponClass == "act3_m3" then
                org = hand.Pos + hand.Ang:Up() * 5 - hand.Ang:Forward() * 2 + hand.Ang:Right() * 0.65
                ang = hand.Ang + Angle(-5,-3,0)
            end
            if weaponClass == "act3_ak" then
                org = hand.Pos + hand.Ang:Up() * 6.6 - hand.Ang:Forward() * -2 + hand.Ang:Right() * 0.8
                ang = hand.Ang + Angle(-5,-1,0)
            end
            if weaponClass == "act3_ar" then
                org = hand.Pos + hand.Ang:Up() * 7.8 - hand.Ang:Forward() * -5 + hand.Ang:Right() * 1
                ang = hand.Ang + Angle(-15,0,0)
            end
            if weaponClass == "act3_atxa2" then
                org = hand.Pos + hand.Ang:Up() * 7.2 - hand.Ang:Forward() * 2 + hand.Ang:Right() * -3.5
                ang = hand.Ang + Angle(-11,0,0)
            end
            if weaponClass == "act3_aug" then
                org = hand.Pos + hand.Ang:Up() * 7.1 - hand.Ang:Forward() * -16 + hand.Ang:Right() * 0.85
                ang = hand.Ang + Angle(-11,0,0)
            end
            if weaponClass == "act3_awp" then
                org = hand.Pos + hand.Ang:Up() * 6.5 - hand.Ang:Forward() * 1 + hand.Ang:Right() * 1.6
                ang = hand.Ang + Angle(-5,0,0)
            end
            if weaponClass == "act3_bar" then
                org = hand.Pos + hand.Ang:Up() * 5 - hand.Ang:Forward() * 1 + hand.Ang:Right() * 0.8
                ang = hand.Ang + Angle(-11,0,0)
            end
            if weaponClass == "act3_c96" then
                org = hand.Pos + hand.Ang:Up() * 4.45 - hand.Ang:Forward() * 6 + hand.Ang:Right() * 0.68
                ang = hand.Ang + Angle(-5,-2,0)
            end
            if weaponClass == "act3_g3" then
                org = hand.Pos + hand.Ang:Up() * 6.6 - hand.Ang:Forward() * -2 + hand.Ang:Right() * 0.8
                ang = hand.Ang + Angle(-5,-1,0)
            end
            if weaponClass == "act3_k98" then
                org = hand.Pos + hand.Ang:Up() * 4.8 - hand.Ang:Forward() * 2 + hand.Ang:Right() * 1.15
                ang = hand.Ang + Angle(-11,0,0)
            end
            if weaponClass == "act3_musket" then
                org = hand.Pos + hand.Ang:Up() * 4.3 - hand.Ang:Forward() * 1 + hand.Ang:Right() * 0.8
                ang = hand.Ang + Angle(-11,0,0)
            end
            if weaponClass == "act3_m11" then
                org = hand.Pos + hand.Ang:Up() * 5.3 - hand.Ang:Forward() * 3 + hand.Ang:Right() * 0.57
                ang = hand.Ang + Angle(-11,0,0)
            end
            if weaponClass == "act3_garand" then
                org = hand.Pos + hand.Ang:Up() * 5.15 - hand.Ang:Forward() * 2 + hand.Ang:Right() * 0.825
                ang = hand.Ang + Angle(-6,0,0)
            end
            if weaponClass == "act3_thompson" then
                org = hand.Pos + hand.Ang:Up() * 3.2 - hand.Ang:Forward() * 9 + hand.Ang:Right() * 0.88
                ang = hand.Ang + Angle(-11,0,0)
            end
            if weaponClass == "act3_m1014" then
                org = hand.Pos + hand.Ang:Up() * 4.5 - hand.Ang:Forward() * 3 + hand.Ang:Right() * 0.88
                ang = hand.Ang + Angle(-11,0,0)
            end
            if weaponClass == "act3_m1919" then
                org = hand.Pos + hand.Ang:Up() * 6.5 - hand.Ang:Forward() * 3 + hand.Ang:Right() * 0.55
                ang = hand.Ang + Angle(-11,0,0)
            end
            if weaponClass == "act3_bazooka" then
                org = hand.Pos + hand.Ang:Up() * 6.5 - hand.Ang:Forward() * 3 + hand.Ang:Right() * -0.8
                ang = hand.Ang + Angle(0,0,0)
            end
            if weaponClass == "act3_m203" then
                org = hand.Pos + hand.Ang:Up() * 8 - hand.Ang:Forward() * 3 + hand.Ang:Right() * 1.175
                ang = hand.Ang + Angle(-11,0,0)
            end
            if weaponClass == "act3_m249" then
                org = hand.Pos + hand.Ang:Up() * 6 - hand.Ang:Forward() * 5 + hand.Ang:Right() * 1.175
                ang = hand.Ang + Angle(-11,0,0)
            end
            if weaponClass == "act3_mg3" then
                org = hand.Pos + hand.Ang:Up() * 6.5 - hand.Ang:Forward() * 5 + hand.Ang:Right() * 1
                ang = hand.Ang + Angle(-11,0,0)
            end
            if weaponClass == "act3_minigun" then
                org = hand.Pos + hand.Ang:Up() * 6 - hand.Ang:Forward() * -15 + hand.Ang:Right() * 1
                ang = hand.Ang + Angle(-11,0,15)
            end
            if weaponClass == "act3_mp40" then
                org = hand.Pos + hand.Ang:Up() * 4.4 - hand.Ang:Forward() * 5 + hand.Ang:Right() * 1
                ang = hand.Ang + Angle(-11,0,0)
            end
            if weaponClass == "act3_p90" then
                org = hand.Pos + hand.Ang:Up() * 8.2 - hand.Ang:Forward() * 5 + hand.Ang:Right() * 0.5
                ang = hand.Ang + Angle(-11,0,0)
            end
            if weaponClass == "act3_rpg7" then
                org = hand.Pos + hand.Ang:Up() * 8.2 - hand.Ang:Forward() * 5 + hand.Ang:Right() * 1.25
                ang = hand.Ang + Angle(-11,5,0)
            end
            if weaponClass == "act3_sg552" then
                org = hand.Pos + hand.Ang:Up() * 4.9 - hand.Ang:Forward() * 5 + hand.Ang:Right() * 1
                ang = hand.Ang + Angle(-11,0,0)
            end
            if weaponClass == "act3_stg44" then
                org = hand.Pos + hand.Ang:Up() * 5.5 - hand.Ang:Forward() * 5 + hand.Ang:Right() * 0.55
                ang = hand.Ang + Angle(-11,-2,0)
            end
            if weaponClass == "act3_tgewehr" then
                org = hand.Pos + hand.Ang:Up() * 5 - hand.Ang:Forward() * 5 + hand.Ang:Right() * 0.95
                ang = hand.Ang + Angle(-11,2,0)
            end
            if weaponClass == "act3_ump" then
                org = hand.Pos + hand.Ang:Up() * 5.2 - hand.Ang:Forward() * 5 + hand.Ang:Right() * 0.7
                ang = hand.Ang + Angle(-11,0,0)
            end
            if weaponClass == "act3_ak100" then
                org = hand.Pos + hand.Ang:Up() * 6.1 - hand.Ang:Forward() * 3 + hand.Ang:Right() * 0.8
                ang = hand.Ang + Angle(-7,0,0)
            end
            if weaponClass == "act3_ak101" then
                org = hand.Pos + hand.Ang:Up() * 6.1 - hand.Ang:Forward() * 3 + hand.Ang:Right() * 0.8
                ang = hand.Ang + Angle(-7,0,0)
            end
            if weaponClass == "act3_ak103" then
                org = hand.Pos + hand.Ang:Up() * 6.1 - hand.Ang:Forward() * 3 + hand.Ang:Right() * 0.8
                ang = hand.Ang + Angle(-7,0,0)
            end
            if weaponClass == "act3_ak105" then
                org = hand.Pos + hand.Ang:Up() * 6.1 - hand.Ang:Forward() * 3 + hand.Ang:Right() * 0.8
                ang = hand.Ang + Angle(-7,0,0)
            end
            if weaponClass == "act3_ak107" then
                org = hand.Pos + hand.Ang:Up() * 6.1 - hand.Ang:Forward() * 3 + hand.Ang:Right() * 0.8
                ang = hand.Ang + Angle(-7,0,0)
            end
            if weaponClass == "act3_ak_mznak74m" then
                org = hand.Pos + hand.Ang:Up() * 6.1 - hand.Ang:Forward() * 3 + hand.Ang:Right() * 0.8
                ang = hand.Ang + Angle(-7,0,0)
            end
            if weaponClass == "act3_ak_am22" then
                org = hand.Pos + hand.Ang:Up() * 6.1 - hand.Ang:Forward() * 3 + hand.Ang:Right() * 0.8
                ang = hand.Ang + Angle(-7,0,0)
            end
            if weaponClass == "act3_ar_a47" then
                org = hand.Pos + hand.Ang:Up() * 6.8 - hand.Ang:Forward() * 3 + hand.Ang:Right() * 0.95
                ang = hand.Ang + Angle(-7,0,0)
            end
            if weaponClass == "act3_ar_ar50" then
                org = hand.Pos + hand.Ang:Up() * 6.1 - hand.Ang:Forward() * 3 + hand.Ang:Right() * 1
                ang = hand.Ang + Angle(-7,0,0)
            end
            if weaponClass == "act3_ar_ar556" then
                org = hand.Pos + hand.Ang:Up() * 6.1 - hand.Ang:Forward() * 3 + hand.Ang:Right() * 1
                ang = hand.Ang + Angle(-7,0,0)
            end
            if weaponClass == "act3_ar57" then
                org = hand.Pos + hand.Ang:Up() * 6.1 - hand.Ang:Forward() * 3 + hand.Ang:Right() * 1
                ang = hand.Ang + Angle(-7,0,0)
            end
            if weaponClass == "act3_ar_ar9" then
                org = hand.Pos + hand.Ang:Up() * 6.1 - hand.Ang:Forward() * 3 + hand.Ang:Right() * 1
                ang = hand.Ang + Angle(-7,0,0)
            end
            if weaponClass == "act3_val" then
                org = hand.Pos + hand.Ang:Up() * 6.3 - hand.Ang:Forward() * 3 + hand.Ang:Right() * 0.8
                ang = hand.Ang + Angle(-7,0,0)
            end
            if weaponClass == "act3_g3_hk33" then
                org = hand.Pos + hand.Ang:Up() * 6.3 - hand.Ang:Forward() * 3 + hand.Ang:Right() * 0.8
                ang = hand.Ang + Angle(-7,0,0)
            end
            if weaponClass == "act3_ar_hk416" then
                org = hand.Pos + hand.Ang:Up() * 6.1 - hand.Ang:Forward() * 3 + hand.Ang:Right() * 1.1
                ang = hand.Ang + Angle(-7,0,0)
            end
            if weaponClass == "act3_ar_hk416c" then
                org = hand.Pos + hand.Ang:Up() * 6.1 - hand.Ang:Forward() * 3 + hand.Ang:Right() * 1.1
                ang = hand.Ang + Angle(-7,0,0)
            end
            if weaponClass == "act3_ar_hk417" then
                org = hand.Pos + hand.Ang:Up() * 6.1 - hand.Ang:Forward() * 3 + hand.Ang:Right() * 1.1
                ang = hand.Ang + Angle(-7,0,0)
            end
            if weaponClass == "act3_lior_mzngalil" then
                org = hand.Pos + hand.Ang:Up() * 5.7 - hand.Ang:Forward() * 3 + hand.Ang:Right() * 1.5
                ang = hand.Ang + Angle(-11,-2,0)
            end
            if weaponClass == "act3_lior_mzngalil_sar" then
                org = hand.Pos + hand.Ang:Up() * 5.7 - hand.Ang:Forward() * 3 + hand.Ang:Right() * 1.5
                ang = hand.Ang + Angle(-11,-2,0)
            end
            if weaponClass == "act3_m249_saw" then
                org = hand.Pos + hand.Ang:Up() * 6.2 - hand.Ang:Forward() * 6 + hand.Ang:Right() * 1.25
                ang = hand.Ang + Angle(-7,0,0)
            end
            if weaponClass == "act3_m2" then
                org = hand.Pos + hand.Ang:Up() * 6 - hand.Ang:Forward() * 1 + hand.Ang:Right() * -0.05
                ang = hand.Ang + Angle(-7,-2,0)
            end
            if weaponClass == "act3_m32" then
                org = hand.Pos + hand.Ang:Up() * 6 - hand.Ang:Forward() * 1 + hand.Ang:Right() * 1.25
                ang = hand.Ang + Angle(-7,0,0)
            end
            if weaponClass == "act3_ar_m4a4" then
                org = hand.Pos + hand.Ang:Up() * 7 - hand.Ang:Forward() * 1 + hand.Ang:Right() * 1.05
                ang = hand.Ang + Angle(-7,0,0)
            end
            if weaponClass == "act3_mb188" then
                org = hand.Pos + hand.Ang:Up() * 5.5 - hand.Ang:Forward() * 1 + hand.Ang:Right() * 0.75
                ang = hand.Ang + Angle(-7,0,0)
            end
            if weaponClass == "act3_m249_minimi" then
                org = hand.Pos + hand.Ang:Up() * 6.2 - hand.Ang:Forward() * 6 + hand.Ang:Right() * 1.25
                ang = hand.Ang + Angle(-7,0,0)
            end
            if weaponClass == "act3_mp5_45" then
                org = hand.Pos + hand.Ang:Up() * 7.3 - hand.Ang:Forward() * -3 + hand.Ang:Right() * 0.9
                ang = hand.Ang + Angle(-5,0,0)
            end
            if weaponClass == "act3_mzn_groza" then
                org = hand.Pos + hand.Ang:Up() * 6.87 - hand.Ang:Forward() * 5 + hand.Ang:Right() * 0.8
                ang = hand.Ang + Angle(-6,0,0)
            end
            if weaponClass == "act3_klesch" then
                org = hand.Pos + hand.Ang:Up() * 4.5 - hand.Ang:Forward() * 12 + hand.Ang:Right() * 0.8
                ang = hand.Ang + Angle(-8,0,0)
            end
            if weaponClass == "act3_ak_mznpp19" then
                org = hand.Pos + hand.Ang:Up() * 5.9 - hand.Ang:Forward() * 5 + hand.Ang:Right() * 0.8
                ang = hand.Ang + Angle(-8,0,0)
            end
            if weaponClass == "act3_rak11" then
                org = hand.Pos + hand.Ang:Up() * 5.9 - hand.Ang:Forward() * 5 + hand.Ang:Right() * 0.8
                ang = hand.Ang + Angle(-8,0,0)
            end
            if weaponClass == "act3_mznsaiga12" then
                org = hand.Pos + hand.Ang:Up() * 5.9 - hand.Ang:Forward() * 5 + hand.Ang:Right() * 0.8
                ang = hand.Ang + Angle(-8,0,0)
            end
            if weaponClass == "act3_mznsaiga12k" then
                org = hand.Pos + hand.Ang:Up() * 5.9 - hand.Ang:Forward() * 5 + hand.Ang:Right() * 0.8
                ang = hand.Ang + Angle(-8,0,0)
            end
            if weaponClass == "act3_coilgun" then
                org = hand.Pos + hand.Ang:Up() * 5.9 - hand.Ang:Forward() * 5 + hand.Ang:Right() * 0.8
                ang = hand.Ang + Angle(-8,0,0)
            end
            if weaponClass == "act3_usp9" then
                org = hand.Pos + hand.Ang:Up() * 4 - hand.Ang:Forward() * 6 + hand.Ang:Right() * 0.23
                ang = hand.Ang + Angle(-5,0,0)
            end
            if weaponClass == "act3_vector_ar" then
                org = hand.Pos + hand.Ang:Up() * 3.4 - hand.Ang:Forward() * 5 + hand.Ang:Right() * 0.85
                ang = hand.Ang + Angle(-18,0,0)
            end
            if weaponClass == "act3_vector" then
                org = hand.Pos + hand.Ang:Up() * 3.4 - hand.Ang:Forward() * 5 + hand.Ang:Right() * 0.85
                ang = hand.Ang + Angle(-18,0,0)
            end
            if weaponClass == "act3_vector_45" then
                org = hand.Pos + hand.Ang:Up() * 3.4 - hand.Ang:Forward() * 5 + hand.Ang:Right() * 0.85
                ang = hand.Ang + Angle(-18,0,0)
            end
            if weaponClass == "act3_bpr_x12" then
                org = hand.Pos + hand.Ang:Up() * 6.6 - hand.Ang:Forward() * 5 + hand.Ang:Right() * 1.10
                ang = hand.Ang + Angle(-11,0,0)
            end
            if weaponClass == "act3_bpr_x16" then
                org = hand.Pos + hand.Ang:Up() * 7.1 - hand.Ang:Forward() * 5 + hand.Ang:Right() * 1.10
                ang = hand.Ang + Angle(-11,0,0)
            end
            if weaponClass == "act3_bpr_x16-1" then
                org = hand.Pos + hand.Ang:Up() * 7.1 - hand.Ang:Forward() * 5 + hand.Ang:Right() * 1.10
                ang = hand.Ang + Angle(-11,0,0)
            end
            if weaponClass == "act3_bpr_x17" then
                org = hand.Pos + hand.Ang:Up() * 5.7 - hand.Ang:Forward() * 5 + hand.Ang:Right() * 1.125
                ang = hand.Ang + Angle(-11,0,0)
            end
            if weaponClass == "act3_ar_sporter" then
                org = hand.Pos + hand.Ang:Up() * 5.3 - hand.Ang:Forward() * 5 + hand.Ang:Right() * 1.125
                ang = hand.Ang + Angle(-6,0,0)
            end
            if weaponClass == "act3_knife" then
                org = hand.Pos + hand.Ang:Up() * 5.3 - hand.Ang:Forward() * 5 + hand.Ang:Right() * 1.125
                ang = hand.Ang + Angle(90,50,0)
            end
            if weaponClass == "act3_ptrd" then
                org = hand.Pos + hand.Ang:Up() * 5.3 - hand.Ang:Forward() * 5 + hand.Ang:Right() * 1.125
                ang = hand.Ang + Angle(-6,0,0)
            end
            if weaponClass == "act3_ptrd_obrez" then
                org = hand.Pos + hand.Ang:Up() * 5.1 - hand.Ang:Forward() * 5 + hand.Ang:Right() * 1.23
                ang = hand.Ang + Angle(-6,0,0)
            end
            if weaponClass == "act3_ptrs" then
                org = hand.Pos + hand.Ang:Up() * 5.3 - hand.Ang:Forward() * 1 + hand.Ang:Right() * 0.7
                ang = hand.Ang + Angle(-11,0,0)
            end